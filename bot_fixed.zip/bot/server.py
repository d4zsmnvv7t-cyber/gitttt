# Точка входа для хостингов, которые по умолчанию запускают server.py
import asyncio
import sys

from main import main

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        pass
    except Exception:
        import logging
        logging.getLogger("giftbot").exception("КРИТИЧЕСКАЯ ОШИБКА")
        sys.exit(1)
